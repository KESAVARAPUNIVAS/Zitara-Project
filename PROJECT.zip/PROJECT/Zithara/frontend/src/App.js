// import logo from './logo.svg';
import './App.css';
import CustomerList from './customerList';

function App() {
  return (
    <div className="App">
      <CustomerList/>
    </div>
  );
}

export default App;
