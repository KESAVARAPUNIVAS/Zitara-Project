# Zithara Round 2

## Steps To Run

# FrontEnd

Step-1 : `npm i` <br>
Step-2 : `npm start`
# BackEnd

Step-1 : `npm i` <br>
Step-2 : `npm start`
# PostgreSQL

Step-1 : Create Database<br>
Step-2 : Create Table<br>
Step-3 : Enter Data
# ENV

Enter the Database-name, Username, Password in the env file